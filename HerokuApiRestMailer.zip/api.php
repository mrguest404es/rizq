<?php
error_reporting(0);
require_once(__DIR__ . '/vendor/autoload.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function num($length = 10) {
  return substr(str_shuffle(str_repeat($x='0123456789', ceil($length/strlen($x)) )),1,$length);
}
function random($length = 10) {
  return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}
$email            = $_REQUEST['list'];
$username         = $_REQUEST['username'];
$password         = $_REQUEST['password'];
$option           = json_decode(urldecode($_REQUEST['option']));
$linkLetter       = $_REQUEST['letter'];
try {
  $mail             = new PHPMailer(false);
  $mail->SMTPDebug  = 0;
  $mail->isSMTP();
  $mail->Host       = 'smtp.pepipost.com';
  $mail->SMTPAuth   = true;
  $mail->Username   = 'toccenaa';
  $mail->Password   = '@@123Kontol';
  $mail->SMTPSecure = 'tls';
  $mail->Port       = 587;

  $mail->setFrom('serv-'.random(5).'@kgsdev.net', $option->from_name);
  $mail->addAddress($email);

  $location         = [
    'Bali, Bali, Indonesia',
    'Semarang, Jawa Tengah, Indonesia',
    'Buenos Aires, Argentina',
    'Sao Paulo, Brazil',
    'Singapore, Singapore',
    'Lombok, Indonesia',
    'Surabaya, Indonesia',
    'Jakarta, Indonesia',
  ];
  $location         = $location[rand(0, count($location)-1)];

  $message          = file_get_contents($linkLetter);
  $message          = str_replace('##email##', $email, $message);
  $message          = str_replace('##random##', strtoupper(random(10)), $message);
  $message          = str_replace('##acak##', num(6), $message);
  $message          = str_replace('##link##', $option->link . '?dispatch=' . random(30), $message);
  $message          = str_replace('##date##', date('m F Y'), $message);
  $message          = str_replace(array('Jakarta, DKI Jakarta, ID', '##location##'), $location, $message);

  $subject          = str_replace('##location##', $location, $option->subject);

  // $mail->isHTML(false);
  $mail->Subject    = $subject;
  $mail->Body       = $message; //$message;
  $mail->AltBody    = 'Text/Plain'; //$message;

  if ($mail->send()) {
    die('OK');
  } else {
    die($mail->ErrorInfo);
  }
} catch (Exception $e) {
  die($mail->ErrorInfo);
  // die('Exception');
}
